import dash_core_components as dcc
import dash_html_components as html
from dash.dependencies import Input, Output
import pandas as pd
from app import app
from .components import Header
import dash_table
df3= pd.read_csv('/Users/Carlsson/Baseball/baseballmd/src/dashboard/pages/datacsv/notebooks_playerStats.csv')



layout = html.Div([
    Header(),
    html.H3('This is the Compare Page'),
    html.Div("Test"),

    html.Div(dash_table.DataTable(
    id='table3',
    columns=[{"name": i, "id":i} for i in df3.columns],
    data=df3.to_dict("rows"),
    style_table={'overflowX': 'scroll'},
    ))
], className="page")
